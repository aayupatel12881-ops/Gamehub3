package com.example.ui
var lastAdShowTime = 0L
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

sealed class BottomNavItem(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Rewards : BottomNavItem("rewards", "Rewards", Icons.Default.Star)
    object TubeFree : BottomNavItem("tube_free", "Tube Free", Icons.Default.PlayArrow)
}

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    
    val items = listOf(
        BottomNavItem.Rewards,
        BottomNavItem.TubeFree
    )
    
    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route
                
                items.forEach { item ->
                    NavigationBarItem(
                        icon = { Icon(item.icon, contentDescription = item.title) },
                        label = { Text(item.title) },
                        selected = currentRoute == item.route,
                        onClick = {
                            navController.navigate(item.route) {
                                navController.graph.startDestinationRoute?.let { route ->
                                    popUpTo(route) {
                                        saveState = true
                                    }
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = BottomNavItem.Rewards.route,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(BottomNavItem.Rewards.route) {
                RewardsScreen()
            }
            composable(BottomNavItem.TubeFree.route) {
                VideoPlayerScreen()
            }
        }
    }
}
